	+----------------------------------------------------------------------------------------------------+
	|                     ZDV ARTCC Combined Sector File Version 5.5 Installation Instructions           |
	+----------------------------------------------------------------------------------------------------+
	|                                         Release Date: 22 Mar 2015                                  |
	|                                             AIRAC Cycle: 1503                                      |
	+----------------------------------------------------------------------------------------------------+


Installation:

1) Unzip the sector file into your root VRC folder, or wherever you store your sector files.
2) Open VRC and select the profile you wish to use.
3) File -> Open Sector -> Select "ZDV_ARTCC_Sector_5.5.sct2" and hit Open.
4) Open the Diagrams menu [CTRL + G], find the section of the STARs menu that relates to the airport you are working, and select the maps you would like to have visable by default.
5) File -> Save Session Profile
6) Repeat for other positions worked.
7) Change the old sector files names.  I put "old" or "bak" in the name somewhere.  That way, when you open up a session profile that you haven't used in a while, it will ding at you, and you will know you need to direct it to the newest verison of the sector file.
8) Enjoy!




Casey Diers
ZDV_CI_FE
DEN ARTCC Facility Engineer
casey@denartcc.org